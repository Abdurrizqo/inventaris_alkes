<?php

namespace App\Filament\Resources\PegawaiUserResource\Pages;

use App\Filament\Resources\PegawaiUserResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePegawaiUser extends CreateRecord
{
    protected static string $resource = PegawaiUserResource::class;
}
